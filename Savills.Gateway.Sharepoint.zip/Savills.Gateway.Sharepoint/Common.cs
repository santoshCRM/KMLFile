﻿using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Savills.Gateway.Sharepoint.ProxyClasses;

namespace Savills.Gateway.Sharepoint
{
    internal static class Common
    {
        internal static string GetConfiguration(IOrganizationService service, string name)
        {
            string configValue = string.Empty;
            Configuration config=  service.FindProxy<Configuration>(Configuration.PrimaryNameAttribute, name, new ColumnSet(Configuration.Properties.Value));
            if (config != null)
            {
                configValue = config.Value;
            }

            return configValue;
            
        }

        internal static string GetListName(IOrganizationService service, string entityName)
        {
            string listname = string.Empty;
            SharePointImageListLocation location = service.FindProxy<SharePointImageListLocation>(SharePointImageListLocation.Properties.EntityName, entityName, new ColumnSet(true));
            if (location != null) { listname = location.SharePointListName; }
            return listname;
        }

        internal static string GetRelativeUrlForDocumentLocation(IOrganizationService service, DocumentLocation documentLocation)
        {
            var relativeUrl = documentLocation.RelativeURL;
            return GetRelativeUrlForDocumentLocation(service, documentLocation, relativeUrl);
        }

        internal static string GetRelativeUrlForDocumentLocation(IOrganizationService service, DocumentLocation documentLocation, string relativeUrl)
        {
            if (documentLocation != null)
            {
                if (documentLocation.ParentSiteOrLocation.LogicalName == DocumentLocation.LogicalName)
                {
                    DocumentLocation parent = service.RetrieveProxy<DocumentLocation>(documentLocation.ParentSiteOrLocation.Id, new ColumnSet(true));
                    relativeUrl = parent.RelativeURL + "/" + relativeUrl;
                    return GetRelativeUrlForDocumentLocation(service, (DocumentLocation)parent, relativeUrl);
                }
                else
                {
                    return "/" + relativeUrl;
                }
            }
            else
            {
                return "/" + relativeUrl;
            }
        }

        internal static string GetFolderNameByMasterListing(IOrganizationService service, Guid masterListingId)
        {
            string folderName = string.Empty;
            QueryExpression query = new QueryExpression(PropertyMarketingInformation.LogicalName);
            query.Criteria.AddCondition(PropertyMarketingInformation.PrimaryIdAttribute, ConditionOperator.Equal, masterListingId);
            LinkEntity propertyAddress = new LinkEntity(PropertyMarketingInformation.LogicalName, PropertyAddress.LogicalName, PropertyMarketingInformation.Properties.PropertyAddress, PropertyAddress.PrimaryIdAttribute, JoinOperator.Inner);
            propertyAddress.Columns = new ColumnSet(PropertyAddress.Properties.SharePointImageFolderName);
            propertyAddress.EntityAlias = "prop";
            query.LinkEntities.Add(propertyAddress);
            EntityCollection results = service.RetrieveMultiple(query);
            if (results != null)
            {
                folderName = ((AliasedValue)((AttributeCollection)results[0].Attributes)["prop." + PropertyAddress.Properties.SharePointImageFolderName]).Value.ToString();
            }
            return folderName;
        }

        internal static string GetFolderNameByBasicListing(IOrganizationService service, Guid basicListingId)
        {
            string folderName = string.Empty;
            QueryExpression query = new QueryExpression(AvailableProperty.LogicalName);
            query.Criteria.AddCondition(AvailableProperty.PrimaryIdAttribute, ConditionOperator.Equal, basicListingId);
            LinkEntity propertyMarketing = new LinkEntity(AvailableProperty.LogicalName, PropertyMarketingInformation.LogicalName, AvailableProperty.Properties.PropertyMarketingInformation, PropertyMarketingInformation.PrimaryIdAttribute, JoinOperator.Inner);
            propertyMarketing.EntityAlias = "propmkt";
            LinkEntity propertyAddress = new LinkEntity(PropertyMarketingInformation.LogicalName, PropertyAddress.LogicalName, PropertyMarketingInformation.Properties.PropertyAddress, PropertyAddress.PrimaryIdAttribute, JoinOperator.Inner);
            propertyAddress.Columns = new ColumnSet(PropertyAddress.Properties.SharePointImageFolderName);
            propertyAddress.EntityAlias = "prop";
            propertyMarketing.LinkEntities.Add(propertyAddress);
            query.LinkEntities.Add(propertyMarketing);
            EntityCollection results = service.RetrieveMultiple(query);
            if (results != null)
            {
                folderName = ((AliasedValue)((AttributeCollection)results[0].Attributes)["prop." + PropertyAddress.Properties.SharePointImageFolderName]).Value.ToString();
            }
            return folderName;
        }

        internal static List<ListingImage> GetImagesByBasicListing(IOrganizationService service, Guid basicListingId)
        {
            ConditionExpression condition = new ConditionExpression(ListingImage.Properties.AvailableProperty, ConditionOperator.Equal, basicListingId);
            List<ListingImage> result = service.RetrieveMultiple(ListingImage.LogicalName, condition, new ColumnSet(true)).ToProxies<ListingImage>();
            return result;
        }

        internal static List<ListingImage> GetImagesByMasterListing(IOrganizationService service, Guid masterListingId)
        {
            ConditionExpression condition = new ConditionExpression(ListingImage.Properties.PropertyMarketingInformation, ConditionOperator.Equal, masterListingId);
            List<ListingImage> result = service.RetrieveMultiple(ListingImage.LogicalName, condition, new ColumnSet(true)).ToProxies<ListingImage>();
            return result;
        }

    }
}
