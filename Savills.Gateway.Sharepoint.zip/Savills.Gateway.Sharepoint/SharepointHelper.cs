﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Json;
using Savills.Gateway.Sharepoint.Sharepoint;

namespace Savills.Gateway.Sharepoint
{
    internal class SharepointHelper
    {
        private string SPUrl;
        private string Username;
        private string Password;
        private string Domain;

        internal SharepointHelper(string SPSiteURL, string SPUserName, string SPPassword, string SPDomain)
        {
            SPUrl = SPSiteURL;
            Username = SPUserName;
            Password = SPPassword;
            Domain = SPDomain;
        }

        internal List<SPFolder> GetSPFolders(string relativeURL)
        {
            MemoryStream stream = GetCall("GetFolderByServerRelativeUrl", relativeURL, "Folders");
            DataContractJsonSerializerSettings settings = new DataContractJsonSerializerSettings();
            settings.UseSimpleDictionaryFormat = true;
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(SPFolderResult), settings);
            StreamReader sr1 = new StreamReader(stream);
            string result1 = sr1.ReadToEnd();
            stream.Seek(0, SeekOrigin.Begin);
            SPFolderResult spresult = (SPFolderResult)ser.ReadObject(stream);
            return spresult.d.results;
        }

        internal List<SPFile> GetSPFiles(string relativeURL)
        {
            MemoryStream stream = GetCall("GetFolderByServerRelativeUrl", relativeURL, "Files");
            DataContractJsonSerializerSettings settings = new DataContractJsonSerializerSettings();
            settings.UseSimpleDictionaryFormat = true;
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(SPFileResult), settings);
            StreamReader sr1 = new StreamReader(stream);
            string result1 = sr1.ReadToEnd();
            stream.Seek(0, SeekOrigin.Begin);
            SPFileResult spresult = (SPFileResult)ser.ReadObject(stream);
            return spresult.d.results;
        }

        internal void CreateFolder(string folderLocation)
        {
            SPFolder folder = new SPFolder(folderLocation);

            DataContractJsonSerializerSettings serSettings = new DataContractJsonSerializerSettings();
            serSettings.UseSimpleDictionaryFormat = true;
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(SPFolder), serSettings);
            MemoryStream postData = new MemoryStream();
            ser.WriteObject(postData, folder);
            PostCall("Folders", postData);
        }


        private MemoryStream GetCall(string command, string param, string resultType)
        {
            try
            {
                MemoryStream ms = GetCallBinary(command, param, resultType);
                ms.Position = 0;
                string result;
                using (StreamReader sr = new StreamReader(ms))
                {
                    result = sr.ReadToEnd();
                }
                byte[] byteArray = Encoding.UTF8.GetBytes(result);
                MemoryStream stream = new MemoryStream(byteArray);
                return stream;
            }
            catch
            {
                throw;
            }
        }

        private MemoryStream GetCallBinary(string command, string param, string resultType)
        {
            try
            {
                string url = SPUrl + @"/_api/web/" + command + @"('" + param + @"')/" + resultType;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = WebRequestMethods.Http.Get;
                request.Accept = @"application/json;odata=verbose";
                request.Credentials = new NetworkCredential(Username, Password, Domain);
                HttpWebResponse response = null;
                response = (HttpWebResponse)request.GetResponse();
                MemoryStream ms = new MemoryStream();
                response.GetResponseStream().CopyTo(ms);
                return ms;
            }
            catch
            {
                throw;
            }
        }

        internal void PostCall(string command, MemoryStream postData)
        {
            string url = SPUrl + @"/_api/web/" + command;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = WebRequestMethods.Http.Post;
            request.Accept = @"application/json;odata=verbose";
            request.ContentType = @"application/json;odata=verbose";
            request.Credentials = new NetworkCredential(Username, Password, Domain);
            postData.Position = 0;
            byte[] buffer = new byte[postData.Length];
            postData.Read(buffer, 0, buffer.Length);
            postData.Close();
            request.ContentLength = buffer.Length;
            request.Headers.Add("X-RequestDigest", GetDigest());
            using (Stream requestStream = request.GetRequestStream())
            {
                requestStream.Write(buffer, 0, buffer.Length);
                requestStream.Close();
            }
            HttpWebResponse response = null;
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (WebException ex)
            {
                var dummy = ex;
            }

        }


        private string GetDigest()
        {
            string digest = string.Empty;
            string formdigestRequest = SPUrl + @"/_api/contextinfo";
        
            HttpWebRequest spRequest = (HttpWebRequest)HttpWebRequest.Create(formdigestRequest);
            spRequest.Credentials = new NetworkCredential(Username, Password, Domain);
            spRequest.CookieContainer = new CookieContainer();
            spRequest.Method = WebRequestMethods.Http.Post;
            spRequest.Accept = "application/json;odata=verbose";
            spRequest.ContentLength = 0;
            Stream postStream;
            HttpWebResponse endpointResponse = (HttpWebResponse)spRequest.GetResponse();
            string results = GetHTTPResponse(endpointResponse, out postStream, out results);

            // Get the FormDigest Value
            var startTag = "FormDigestValue";
            var endTag = "LibraryVersion";
            var startTagIndex = results.IndexOf(startTag) + 1;
            var endTagIndex = results.IndexOf(endTag, startTagIndex);
            if ((startTagIndex >= 0) && (endTagIndex > startTagIndex))
            {
                digest = results.Substring(startTagIndex + startTag.Length + 2, endTagIndex - startTagIndex - startTag.Length - 5);
            }
            return digest;
        }
        private static String GetHTTPResponse(HttpWebResponse endpointResponse, out Stream postStream, out string results)
        {
            postStream = endpointResponse.GetResponseStream();
            StreamReader postReader = new StreamReader(postStream);
            results = postReader.ReadToEnd();
            postReader.Close();
            postStream.Close();
            return results;
        }

        internal void UploadFile(string folderName, string fileName, MemoryStream data)
        {
            PostCall("GetFolderByServerRelativeUrl('" + folderName + "')/Files/add(url='" + fileName + "',overwrite=true)", data);
        }

        internal MemoryStream GetFile(string url)
        {
            return GetCallBinary("GetFileByServerRelativeUrl", url, "$value");

        }
    }
}
