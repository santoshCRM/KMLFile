using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using Savills.Gateway.Sharepoint.ProxyClasses;
using Microsoft.Crm.Sdk.Messages;

namespace Savills.Gateway.Sharepoint
{
    public partial class AddFloorPlansToEmail : BaseWorkflow
    {
        // This is an example argument
        [RequiredArgument]
        [Input("Select an email to send")]
        [ReferenceTarget("email")]
        public InArgument<EntityReference> EmailReference { get; set; }
        
        protected override void ExecuteInternal(LocalWorkflowContext context)
        {
            // Todo: implement your logic here
            var emailRef = this.EmailReference.Get(context.CodeActivityContext);
            ListingSend send = new ListingSend();
            send.Id = context.WorkflowContext.PrimaryEntityId;
            List<AvailableProperty> listings = mcs_mcs_listingsend_mcs_alisting.GetRelatedManyToManyEntities<AvailableProperty>( context.OrganizationService,send , ListingSend.LogicalName, ListingSend.PrimaryIdAttribute,
                   AvailableProperty.LogicalName, AvailableProperty.PrimaryIdAttribute, mcs_mcs_listingsend_mcs_alisting.LogicalName, mcs_mcs_listingsend_mcs_alisting.Properties.Mcs_listingsendid, 
                   mcs_mcs_listingsend_mcs_alisting.Properties.Mcs_alistingid, new ColumnSet(true));
            if (listings !=null)
            {
                SharePointSite site = context.OrganizationService.FindProxy<SharePointSite>(SharePointSite.Properties.DefaultSite, true, new ColumnSet(true));
                if (site != null)
                {
                    SharepointHelper spHelper = new SharepointHelper(site.AbsoluteURL, Common.GetConfiguration(context.OrganizationService, "SharePointUsername"),
                                    Common.GetConfiguration(context.OrganizationService, "SharePointPassword"), Common.GetConfiguration(context.OrganizationService, "SharePointDomain"));
                    foreach (AvailableProperty listing in listings)
                    {
                        QueryExpression query = new QueryExpression(ListingDocument.LogicalName);
                        query.ColumnSet = new ColumnSet(true);
                        query.Criteria.AddCondition(new ConditionExpression(ListingDocument.Properties.AvailableProperty, ConditionOperator.Equal, listing.Id));
                        query.Criteria.AddCondition(new ConditionExpression(ListingDocument.Properties.DocumentType, ConditionOperator.Equal, (int)ListingDocument.eDocumentType.FloorPlan));
                        query.AddOrder(ListingDocument.Properties.CreatedOn, OrderType.Descending);
                        List<ListingDocument> floorplans = context.OrganizationService.RetrieveProxies<ListingDocument>(query).ToList<ListingDocument>();
                        if (floorplans != null && floorplans.Count > 0)
                        {
                            
                            DocumentLocation docLocation = context.OrganizationService.FindProxy<DocumentLocation>(DocumentLocation.Properties.Regarding, listing.Id, new ColumnSet(true));
                            string relativeUrl = Common.GetRelativeUrlForDocumentLocation(context.OrganizationService, docLocation);
                            var file = spHelper.GetFile(relativeUrl + "/" + floorplans[0].Name);
                            using (MemoryStream ms = new MemoryStream())
                            {
                                file.Position = 0;
                                file.CopyTo(ms);
                                Attachment attachment = new Attachment();
                                attachment.Item = new EntityReference(EmailReference.Get(context.CodeActivityContext).LogicalName, EmailReference.Get(context.CodeActivityContext).Id);
                                attachment.Entity = EmailReference.Get(context.CodeActivityContext).LogicalName;
                                attachment.FileName = floorplans[0].Name;
                                ms.Position = 0;
                                attachment.Body = Convert.ToBase64String(ms.ToArray());
                                context.OrganizationService.Create(attachment);
                            }
                        }
                    }
                }

            }

        }
    }
}

