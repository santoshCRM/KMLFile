using System;
using System.Collections.Generic;
using System.Linq;
using Savills.Gateway.Sharepoint.ProxyClasses;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;

using Savills.Gateway.Sharepoint.Sharepoint;

namespace Savills.Gateway.Sharepoint
{
    public partial class CopyTemplatesToDocumentLocation : BaseWorkflow
    {
        protected override void ExecuteInternal(LocalWorkflowContext context)
        {
            if (context.WorkflowContext.PrimaryEntityName == DocumentLocation.LogicalName)
            {
                DocumentLocation documentLocation = context.OrganizationService.RetrieveProxy<DocumentLocation>(context.WorkflowContext.PrimaryEntityId, new Microsoft.Xrm.Sdk.Query.ColumnSet(true));
                var regardingObject = documentLocation.Regarding;
                context.TracingService.Trace("Validate regarding object");
                if (regardingObject != null && (regardingObject.LogicalName == Opportunity.LogicalName || regardingObject.LogicalName == Appointment_Job.LogicalName))
                {
                    EntityReference oppotunityOrAppointmentType = null;

                    int typeValue = (int) Opportunity_AppointmentTemplateLocation.eEntity.Oppotunity;
                    context.TracingService.Trace("Identity regarding object type");
                    if (regardingObject.LogicalName == Opportunity.LogicalName)
                    {
                        context.TracingService.Trace("Type is Opportunity");
                        oppotunityOrAppointmentType = new EntityReference(Opportunity_AppointmentType.LogicalName, 
                                    context.OrganizationService.RetrieveProxy<Opportunity>(regardingObject.Id, new ColumnSet(Opportunity.Properties.OpportunityType)).OpportunityType.Id);
                        typeValue = (int) Opportunity_AppointmentTemplateLocation.eEntity.Oppotunity;
                    }
                    else
                    {
                        context.TracingService.Trace("Type is Appointment");
                        oppotunityOrAppointmentType = new EntityReference(Opportunity_AppointmentType.LogicalName, 
                                    context.OrganizationService.RetrieveProxy<Appointment_Job>(regardingObject.Id, new ColumnSet(Appointment_Job.Properties.AppointmentType)).AppointmentType.Id);
                        typeValue = (int) Opportunity_AppointmentTemplateLocation.eEntity.Appointment;
                    }

                    if (oppotunityOrAppointmentType != null)
                    {
                        context.TracingService.Trace("Retrieve location record");
                        QueryExpression query = new QueryExpression(Opportunity_AppointmentTemplateLocation.LogicalName);
                        query.ColumnSet = new ColumnSet(true);
                        query.Criteria.AddCondition(Opportunity_AppointmentTemplateLocation.Properties.Entity, ConditionOperator.Equal, typeValue);
                        query.Criteria.AddCondition(Opportunity_AppointmentTemplateLocation.Properties.Opportunity_AppointmentType, ConditionOperator.Equal, oppotunityOrAppointmentType.Id);
                        Opportunity_AppointmentTemplateLocation templateLocation = null;
                        List<Opportunity_AppointmentTemplateLocation> locations = context.OrganizationService.RetrieveProxies<Opportunity_AppointmentTemplateLocation>(query);
                        if (locations != null)
                        {
                            if (locations.Count > 0) { templateLocation = locations[0]; }
                        }
                        if (templateLocation != null)
                        {
                            context.TracingService.Trace("Folder Location: " + templateLocation.FolderLocation);
                            //Get default sharepoint site
                            context.TracingService.Trace("Retrieve sharepoint site");
                            SharePointSite site = context.OrganizationService.FindProxy<SharePointSite>(SharePointSite.Properties.DefaultSite, true, new ColumnSet(true));
                            if (site != null)
                            {
                                context.TracingService.Trace("Sharepoint Site: " + site.AbsoluteURL);
                                context.TracingService.Trace("This object relative url: " + Common.GetRelativeUrlForDocumentLocation(context.OrganizationService, documentLocation));
                                SharepointHelper spHelper = new SharepointHelper(site.AbsoluteURL, Common.GetConfiguration(context.OrganizationService, "SharePointUsername"), 
                                                Common.GetConfiguration(context.OrganizationService, "SharePointPassword"), Common.GetConfiguration(context.OrganizationService, "SharePointDomain"));
                                context.TracingService.Trace("Copy Folder");
                                CopyFolderContents(spHelper, templateLocation.FolderLocation, Common.GetRelativeUrlForDocumentLocation(context.OrganizationService, documentLocation));
                            }
                        }
                    }
                }
            }


        }


        static void CopyFolderContents(SharepointHelper spHelper, string sourceFolder, string destFolder)
        {
            List<SPFile> files = spHelper.GetSPFiles(sourceFolder);
            foreach (SPFile file in files)
            {
                spHelper.UploadFile(destFolder, file.Name, spHelper.GetFile(file.ServerRelativeUrl));
            }
            List<SPFolder> srcFolders = spHelper.GetSPFolders(sourceFolder);
            foreach (SPFolder folder in srcFolders)
            {
                string newFolder = destFolder + @"/" + folder.Name;
                spHelper.CreateFolder(newFolder);
                CopyFolderContents(spHelper, folder.ServerRelativeUrl, newFolder);
            }


        }
      
    }

}

