using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Crm.Sdk.Messages;
using Savills.Gateway.Sharepoint.ProxyClasses;
namespace Savills.Gateway.Sharepoint
{
    public partial class CopyMasterListingImagetoBasicListing : BaseWorkflow
    {
        
        
        protected override void ExecuteInternal(LocalWorkflowContext context)
        {
            try
            {
                AvailableProperty availableProp = context.OrganizationService.RetrieveProxy<AvailableProperty>(context.WorkflowContext.PrimaryEntityId,
                        new ColumnSet(AvailableProperty.Properties.PropertyMarketingInformation, AvailableProperty.Properties.SharepointImageFolderName));

                if (availableProp != null &&  availableProp.PropertyMarketingInformation != null)
                {
                    PropertyMarketingInformation masterListing = context.OrganizationService.RetrieveProxy<PropertyMarketingInformation>(availableProp.PropertyMarketingInformation.Id, 
                        new ColumnSet(PropertyMarketingInformation.Properties.SharepointImageFolderName));
                    if (masterListing != null && !String.IsNullOrEmpty(masterListing.SharepointImageFolderName))
                    {

                        QueryExpression query = new QueryExpression(ListingImage.LogicalName);

                        query.ColumnSet = new ColumnSet(true);
                        query.AddOrder(ListingImage.Properties.SortOrder,OrderType.Ascending);
                        query.AddOrder(ListingImage.Properties.CreatedOn, OrderType.Ascending);
                        query.Criteria.AddCondition(new ConditionExpression(ListingImage.Properties.PropertyMarketingInformation, ConditionOperator.Equal, masterListing.Id));
                        List<ListingImage> listingImages = context.OrganizationService.RetrieveProxies<ListingImage>(query).ToList<ListingImage>();
                        if (listingImages != null)
                        {
                           
                            var masterListingListName = Common.GetListName(context.OrganizationService, PropertyMarketingInformation.LogicalName);
                            var masterListingFolderName = masterListing.SharepointImageFolderName;
                            var basicListingListName = Common.GetListName(context.OrganizationService, AvailableProperty.LogicalName);
                            var basicListingFolderName =  availableProp.SharepointImageFolderName;

                            foreach (ListingImage i in listingImages)
                            {
                                //1.Copy SharePoint File
                                var imageRelativeUrl = String.Format("/{0}/{1}/{2}", masterListingListName, masterListingFolderName, i.ImageName);

                                var newImageRelativeUrl = String.Format("/{0}/{1}", basicListingListName, basicListingFolderName);

                                try
                                {
                                    SharepointHelper spHelper = new SharepointHelper(Common.GetConfiguration(context.OrganizationService, "SharePointImageSiteUrl"), Common.GetConfiguration(context.OrganizationService, "SharePointUsername"),
                                     Common.GetConfiguration(context.OrganizationService, "SharePointPassword"), Common.GetConfiguration(context.OrganizationService, "SharePointDomain"));
                                    spHelper.UploadFile(newImageRelativeUrl, i.ImageName, spHelper.GetFile(imageRelativeUrl));
                                    ListingImage newBasicListingImage = new ListingImage();
                                    newBasicListingImage.AvailableProperty = new EntityReference(AvailableProperty.LogicalName, context.WorkflowContext.PrimaryEntityId);
                                    newBasicListingImage.ImageName = i.ImageName;
                                    newBasicListingImage.OriginalImageUrl= i.OriginalImageUrl;
                                    newBasicListingImage.SortOrder = i.SortOrder;
                                    newBasicListingImage.IsHeroMage = i.IsHeroMage;
                                    context.OrganizationService.Create(newBasicListingImage);

                                    //To fix issue when coming to sorting by createdon field
                                    Thread.Sleep(200);
                                }
                                catch (Exception ex)
                                {
                                    //Could not load image file skip

                                    context.TracingService.Trace(String.Format("Error retrieving image file {0} : {1}", imageRelativeUrl, ex.Message));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        
    }
}

