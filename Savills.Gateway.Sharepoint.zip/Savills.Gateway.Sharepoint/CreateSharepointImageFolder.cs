using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Workflow;
using Savills.Gateway.Sharepoint.ProxyClasses;


namespace Savills.Gateway.Sharepoint
{
    public partial class CreateSharepointImageFolder : BaseWorkflow
    {
        [Input("Record Name")]
        [RequiredArgument]
        public InArgument<string> RecordName { get; set; }
        [Output("Folder Name")]
        public OutArgument<string> FolderName { get; set; }


        protected override void ExecuteInternal(LocalWorkflowContext context)
        {
            string listName = Common.GetListName(context.OrganizationService, context.WorkflowContext.PrimaryEntityName);
            if (!String.IsNullOrEmpty(listName))
            {

               
                string invalid = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars());
                var recordName = RecordName.Get<String>(context.CodeActivityContext);
                foreach (char c in invalid)
                {
                    recordName = recordName.Replace(c.ToString(), "");
                }
                recordName = recordName.Replace(@"&", "and");
                string folderName = recordName + "_" + context.WorkflowContext.PrimaryEntityId.ToString();
                string fullFolderRelativeUrl = listName + "/" + folderName;
                SharepointHelper spHelper = new SharepointHelper(Common.GetConfiguration(context.OrganizationService, "SharePointImageSiteUrl"), Common.GetConfiguration(context.OrganizationService, "SharePointUsername"),
                                               Common.GetConfiguration(context.OrganizationService, "SharePointPassword"), Common.GetConfiguration(context.OrganizationService, "SharePointDomain"));
                spHelper.CreateFolder(fullFolderRelativeUrl);

                FolderName.Set(context.CodeActivityContext, folderName);
            }
        }


      
    }

}

