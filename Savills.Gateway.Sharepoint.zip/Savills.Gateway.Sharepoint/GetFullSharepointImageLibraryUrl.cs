using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Crm.Sdk.Messages;

namespace Savills.Gateway.Sharepoint
{
    public partial class GetFullSharepointImageLibraryUrl : BaseWorkflow
    {
        [Input("Folder Name")]
        [RequiredArgument]
        public InArgument<string> FolderName { get; set; }
        [Input("Entity Name")]
        [RequiredArgument]
        public InArgument<string> EntityName { get; set; }

        [Output("Full Url")]
        public OutArgument<string> FullUrl { get; set; }

        protected override void ExecuteInternal(LocalWorkflowContext context)
        {
            string siteUrl = Common.GetConfiguration(context.OrganizationService, "SharePointImageSiteUrl");
            string listName = Common.GetListName(context.OrganizationService, EntityName.Get(context.CodeActivityContext));
            if (!String.IsNullOrEmpty(siteUrl) && !string.IsNullOrEmpty(listName))
            {
                if (siteUrl.EndsWith("/"))
                {
                    FullUrl.Set(context.CodeActivityContext, siteUrl + listName + "/" + FolderName.Get(context.CodeActivityContext));
                }
                else
                {
                    FullUrl.Set(context.CodeActivityContext, siteUrl + "/" + listName + "/" + FolderName.Get(context.CodeActivityContext));
                }
            }
        }
    }
}

