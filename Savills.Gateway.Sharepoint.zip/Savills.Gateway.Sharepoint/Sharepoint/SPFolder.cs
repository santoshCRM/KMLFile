﻿using System.Collections.Generic;
using System.Runtime.Serialization;



namespace Savills.Gateway.Sharepoint.Sharepoint
{
    [DataContract]
    public class SPFolder
    {
        public SPFolder(string FolderName)
        {
            __metadata = new Sharepoint.SPItem();
            __metadata.type = "SP.Folder";
            ServerRelativeUrl = FolderName;
        }

        [DataMember]
        public SPItem __metadata { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public string Name { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public string ServerRelativeUrl { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public int ItemCount { get; set; }
    }

    [DataContract]
    public class SPFolderResult
    {
        [DataMember]
        public SPFolders d { get; set; }
    }

    [DataContract]
    public class SPFolders
    {
        [DataMember]
        public List<SPFolder> results { get; set; }
    }
}
