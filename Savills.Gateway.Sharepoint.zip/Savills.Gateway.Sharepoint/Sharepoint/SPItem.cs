﻿using System.Runtime.Serialization;


namespace Savills.Gateway.Sharepoint.Sharepoint
{
    [DataContract]
    public class SPItem
    {
        [DataMember(EmitDefaultValue = false)]
        public string id { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public string uri { get; set; }
        [DataMember]
        public string type { get; set; }
    }
}
