﻿using System.Collections.Generic;
using System.Runtime.Serialization;


namespace Savills.Gateway.Sharepoint.Sharepoint
{
    [DataContract]
    public class SPFile
    {
        [DataMember]
        public SPItem __metadata { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string ServerRelativeUrl { get; set; }
        [DataMember]
        public bool Exists { get; set; }
        [DataMember]
        public string Length { get; set; }
        [DataMember]
        public string ContentTag { get; set; }
        [DataMember]
        public string ETag { get; set; }
    }

    [DataContract]
    public class SPFileResult
    {
        [DataMember]
        public SPFiles d { get; set; }
    }

    [DataContract]
    public class SPFiles
    {
        [DataMember]
        public List<SPFile> results { get; set; }
    }
}
