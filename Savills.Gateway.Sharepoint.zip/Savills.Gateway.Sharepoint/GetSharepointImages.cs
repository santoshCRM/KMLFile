using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using System.IO;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using Savills.Gateway.Sharepoint.ProxyClasses;
using Savills.Gateway.Sharepoint.Sharepoint;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using Microsoft.Crm.Sdk.Messages;

namespace Savills.Gateway.Sharepoint
{
    public partial class GetSharepointImages : BaseWorkflow
    {
        [Input("Basic Listing")]
        [RequiredArgument]
        [ReferenceTarget("mcs_alisting")]
        public InArgument<EntityReference> BasicListing { get; set; }

        [Input("Master Listing")]
        [RequiredArgument]
        [ReferenceTarget("mcs_alistingcampaign")]
        public InArgument<EntityReference> MasterListing { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        protected override void ExecuteInternal(LocalWorkflowContext context)
        {
            try
            {
                string listName = Common.GetListName(context.OrganizationService, PropertyAddress.LogicalName);
                if (!String.IsNullOrEmpty(listName))
                {
                    string folderName = string.Empty;
                    string listingImageListName = string.Empty;
                    Dictionary<Guid, string> existingImages = new Dictionary<Guid, string>();
                    if (BasicListing.Get<EntityReference>(context.CodeActivityContext) != null)
                    {

                        folderName = Common.GetFolderNameByBasicListing(context.OrganizationService, BasicListing.Get<EntityReference>(context.CodeActivityContext).Id);
                        existingImages = Common.GetImagesByBasicListing(context.OrganizationService, BasicListing.Get<EntityReference>(context.CodeActivityContext).Id).ToDictionary(i => i.Id, i => i.ImageName);
                        listingImageListName = Common.GetListName(context.OrganizationService, BasicListing.Get<EntityReference>(context.CodeActivityContext).LogicalName);
                    }
                    else if (MasterListing.Get<EntityReference>(context.CodeActivityContext) != null)
                    {
                        folderName = Common.GetFolderNameByMasterListing(context.OrganizationService, MasterListing.Get<EntityReference>(context.CodeActivityContext).Id);
                        existingImages = Common.GetImagesByMasterListing(context.OrganizationService, MasterListing.Get<EntityReference>(context.CodeActivityContext).Id).ToDictionary(i => i.Id, i => i.ImageName);
                        listingImageListName = Common.GetListName(context.OrganizationService, MasterListing.Get<EntityReference>(context.CodeActivityContext).LogicalName);
                    }
                    if (!String.IsNullOrEmpty(folderName))
                    {
                        string siteURL = Common.GetConfiguration(context.OrganizationService, "SharePointImageSiteUrl");
                        List<Photo> results = new List<Photo>();
                        SharepointHelper spHelper = new SharepointHelper(siteURL, Common.GetConfiguration(context.OrganizationService, "SharePointUsername"),
                                         Common.GetConfiguration(context.OrganizationService, "SharePointPassword"), Common.GetConfiguration(context.OrganizationService, "SharePointDomain"));
                        List<SPFile> files = spHelper.GetSPFiles(listName + "/" + folderName);
                        foreach (SPFile file in files)
                        {
                            results.Add(
                                new Photo
                                {
                                    ServerRelativeUrl = file.ServerRelativeUrl,
                                    Name = file.Name,
                                    FullUrl = (siteURL.EndsWith("/") ? siteURL : siteURL + "/") + file.ServerRelativeUrl,
                                    IsAdded = existingImages.ContainsValue(file.ServerRelativeUrl),
                                    ImageId = existingImages.Where(i => i.Value == file.ServerRelativeUrl).Select(i => i.Key).FirstOrDefault()
                                }
                            );
                        }
                        DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Photo));
                        MemoryStream postData = new MemoryStream();
                        ser.WriteObject(postData, results);
                        string decoded = Encoding.UTF8.GetString(postData.ToArray());
                        Result.Set(context.CodeActivityContext, decoded);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        [DataContract]
        public class Photo
        {
            [DataMember]
            public string ServerRelativeUrl { get; set; }
            [DataMember]
            public string FullUrl { get; set; }
            [DataMember]
            public string Name { get; set; }
            [DataMember]
            public bool IsAdded { get; set; }
            [DataMember]
            public Guid? ImageId { get; set; }
        }

    }
}

